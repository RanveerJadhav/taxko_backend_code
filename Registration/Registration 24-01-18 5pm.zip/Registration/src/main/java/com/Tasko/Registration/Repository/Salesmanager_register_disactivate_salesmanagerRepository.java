package com.Tasko.Registration.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.Salesman_Register;
import com.Tasko.Registration.Entity.Salesmanager_register_disactivate_salesmanager;

public interface Salesmanager_register_disactivate_salesmanagerRepository extends JpaRepository<Salesmanager_register_disactivate_salesmanager, Long>{

	Optional<Salesmanager_register_disactivate_salesmanager> findByPan(String pan);

}
