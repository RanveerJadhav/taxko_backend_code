package com.Tasko.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.Distributor_email_help;




public interface Distributor_email_helpRepository extends JpaRepository<Distributor_email_help, Long>{

}
