package com.Tasko.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.UserEmail_help;
public interface UserEmail_helpRepository extends JpaRepository<UserEmail_help,Long> {

}
