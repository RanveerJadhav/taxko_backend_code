package com.Tasko.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.User_seggesion;

public interface User_seggesionRepository extends JpaRepository<User_seggesion, Long>{

}
