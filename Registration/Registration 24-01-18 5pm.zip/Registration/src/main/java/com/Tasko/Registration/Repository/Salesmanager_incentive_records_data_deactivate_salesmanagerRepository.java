package com.Tasko.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.Salesmanager_incentive_records_data_deactivate_salesmanager;

public interface Salesmanager_incentive_records_data_deactivate_salesmanagerRepository extends JpaRepository<Salesmanager_incentive_records_data_deactivate_salesmanager, Long>{

}
