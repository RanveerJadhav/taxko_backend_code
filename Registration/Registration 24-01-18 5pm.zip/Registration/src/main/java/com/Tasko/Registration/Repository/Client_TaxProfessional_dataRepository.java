package com.Tasko.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.Client_TaxProfessional_data;

public interface Client_TaxProfessional_dataRepository extends JpaRepository<Client_TaxProfessional_data, Long> {

}
