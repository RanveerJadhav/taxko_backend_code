package com.Tasko.Registration.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Tasko.Registration.Entity.Refer_a_friend;

public interface Refer_a_friendRepository extends JpaRepository<Refer_a_friend, Long> {

}
